create
    definer = dev@`%` procedure insert_new_report(IN reporting_user_id varchar(255), IN reported_user_id varchar(255),
                                                  IN reason varchar(255), IN created_at varchar(255))
BEGIN

INSERT INTO report (
		report.reporting_user_id,
		report.reported_user_id,
		report.reason,
		report.created_at,
        report.handled_at
	)
	VALUES (
		reporting_user_id,
		reported_user_id,
		reason,
        created_at,
        NULL
    );

END;

